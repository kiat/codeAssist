import unittest
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.discover('tests')
    with open('/usr/app/results.json', 'w') as f:
        JSONTestRunner(visibility='visible', stream=f).run(suite)
    
    with open('/usr/app/results.json', 'r') as f:
        print(f.read())
