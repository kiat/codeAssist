# Reads two integers from input and prints their sum
a, b = map(int, input().split())
print(a + b)
